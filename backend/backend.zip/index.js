const Application = require("./app/server.js");
new Application();
